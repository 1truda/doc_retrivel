📦 User Guide (For Windows Users)  

🔑 **Before First Use**:  
------------------------  
Run by double-clicking:  
👉 `first_time_setup.bat`  

This script will:  
- Automatically generate an SSH key and upload it to the server.  
- You only need to enter the remote server's root password once (automatically saved).  

**Password**: `pMkw7E+LF0pG`  

🌐 **Daily Use**:  
------------------------  
Run by double-clicking:  
👉 `run_streamlit.bat`  

This script will automatically:  
1. Connect to the server  
2. Forward the port  
3. Launch your browser to `http://localhost:8501`  

📌 **Important Notes**:  
------------------------  
- **Do not move or delete files** in the folder.  
- If double-clicking `.bat` doesn't work, **right-click and "Run as Administrator"**.  
- If you see an error that `ssh` is not recognized, install **[Git for Windows](https://git-scm.com/download/win)**.  
- Ensure a stable network connection and **do not use a VPN**.  