📦 Streamlit 应用使用说明（首次用户）

1. 第一次使用前，请双击：
   ▶️ first_time_setup.command
   作用：自动配置 SSH 密钥、免密登录

   密码：pMkw7E+LF0pG

2. 正常启动应用：
   ▶️ 双击 run_streamlit.command
   启动后浏览器会自动打开 http://localhost:8501

📌 注意事项：
- 确保网络畅通,不要使用VPN
- 如果提示“打不开因为未被信任”，请去“系统偏好设置 ➜ 安全性与隐私”允许
- 请勿移动这些文件之间的相对位置，否则启动会失败
- 若双击 .command 无法运行，请右键点击文件 -> 显示简介 -> 勾选“允许任何来源”
或手动打开终端执行：chmod +x first_time_setup.command